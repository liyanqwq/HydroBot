/* eslint-disable no-eval */
import crypto from 'crypto';
import { internal, mapDirectory } from 'koishi-plugin-eval/lib/worker';
import moment from 'moment';
import superagent from 'superagent';
import _ from 'lodash';
import yaml from 'js-yaml';

internal.setGlobal('crypto', crypto, false);
internal.setGlobal('moment', moment, false);
internal.setGlobal('_', _, false);
internal.setGlobal('yaml', yaml, false);
internal.setGlobal('superagent', superagent, false);
mapDirectory('moment', eval('require').resolve('moment'));
mapDirectory('lodash', eval('require').resolve('lodash'));
mapDirectory('js-yaml', eval('require').resolve('js-yaml'));
mapDirectory('superagent', eval('require').resolve('superagent'));
