import { createWriteStream, existsSync, unlinkSync } from 'fs';
import AdmZip from 'adm-zip';
import superagent from 'superagent';
import { join, resolve } from 'path';
import { cwd } from 'process';
// eslint-disable-next-line no-use-before-define
import React from 'react';
import DomServer from 'react-dom/server';
import {
    copySync, mkdirpSync, removeSync, rename, writeFile,
} from 'fs-extra';
import { Context, Logger, s } from 'koishi-core';

const _assets = resolve(cwd(), 'assets');
const assets = (strings, arg0?) => (arg0 ? join(_assets, strings[0] + arg0 + strings[1]) : (strings[0] ? join(_assets, strings[0]) : _assets));
if (!existsSync(assets``)) mkdirpSync(assets``);
const _tmp = resolve(cwd(), '.tmp');
const tmp = (strings) => (strings[0] ? join(_tmp, strings[0]) : _tmp);
const logger = new Logger('arcaea');

declare module 'koishi-core' {
    interface User {
        arcId: string
    }
}
interface ArcConfig {
    useragent: string;
    endpoint: string;
}

function init() {
    if (existsSync(assets`arc.xapk`)) {
        logger.info('Unpacking arc.xapk');
        const zip = new AdmZip(assets`arc.xapk`);
        zip.extractEntryTo('arcassets.apk', assets``, false, true);
        rename(assets`arcassets.apk`, assets`arc.apk`);
        unlinkSync(assets`arc.xapk`);
    }
    if (existsSync(assets`arc.apk`)) {
        logger.info('Unpacking arc.apk');
        const zip = new AdmZip(assets`arc.apk`);
        zip.extractAllTo(tmp`arc`);
        copySync(tmp`arc/assets`, assets`arcaea`, { dereference: true, overwrite: true });
        removeSync(tmp`arc`);
        removeSync(assets`arc.apk`);
    }
    copySync(assets`_/arcaea/`, assets`arcaea/_`, { dereference: true, overwrite: true });
    if (global.gc) global.gc();
}

init();

const root = `file://${assets`arcaea`}`.replace(/\\/g, '/');
const commonStyle = `
html, body, div, span, applet, object, iframe,
h1, h2, h3, h4, h5, h6, p, blockquote, pre,
a, abbr, acronym, address, big, cite, code,
del, dfn, em, img, ins, kbd, q, s, samp,
small, strike, strong, sub, sup, tt, var,
b, u, i, center,
dl, dt, dd, ol, ul, li,
fieldset, form, label, legend,
table, caption, tbody, tfoot, thead, tr, th, td,
article, aside, canvas, details, embed,
figure, figcaption, footer, header, hgroup,
menu, nav, output, ruby, section, summary,
time, mark, audio, video {
    margin: 0;
    padding: 0;
    border: 0;
    font-size: 100%;
    font: inherit;
    vertical-align: baseline;
}
article, aside, details, figcaption, figure,
footer, header, hgroup, menu, nav, section {
    display: block;
}
body { line-height: 1; overflow: hidden; }
ol, ul { list-style: none; }
blockquote, q { quotes: none; }
blockquote:before, blockquote:after,
q:before, q:after { content: ''; content: none; }
table {
    border-collapse: collapse;
    border-spacing: 0;
}
@font-face {
    font-family: "Kazesawa";
    src: url(${root}/Fonts/Kazesawa-Regular.ttf)
}
@font-face {
  font-family: "Kazesawa";
  src: url(${root}/Fonts/Kazesawa-Light.ttf);
  font-style: light;
}
@font-face {
    font-family: "Exo";
    src: url(${root}/Fonts/Exo-Regular.ttf)
}
@font-face {
  font-family: "Exo";
  src: url(${root}/Fonts/Exo-Light.ttf);
  font-style: light;
}`;

export function apply(ctx: Context, config: ArcConfig) {
    if (!config.endpoint.endsWith('/')) config.endpoint += '/';

    async function getB30(id: number | string) {
        const numbers = Array.from({ length: 30 }, (v, k) => k + 1);
        const params = {
            calls: JSON.stringify([
                {
                    id: 0,
                    endpoint: `user/best30?${typeof id === 'number' ? 'usercode' : 'user'}=${id}`,
                    bind: numbers.reduce((result, num) => {
                        result[`$song_${num}`] = `best30_list[${num - 1}].song_id`;
                        return result;
                    }, {}),
                },
                {
                    id: 1,
                    endpoint: `user/info?${typeof id === 'number' ? 'usercode' : 'user'}=${id}`,
                },
                ...numbers.map((v) => ({
                    id: v + 1,
                    endpoint: `song/info?songname=$song_${v}`,
                })),
            ]),
        };
        const res = await superagent.get(`${config.endpoint}v4/batch`)
            .set('User-Agent', config.useragent).query(params);
        if (res.body.status !== 0) throw new Error(res.body.message);
        return res.body.content.map((i) => (i.result.status === 0 ? i.result.content : i.result.status));
    }

    async function getRecent(id: number | string) {
        const params = {
            calls: JSON.stringify([
                {
                    id: 0,
                    endpoint: `user/info?${typeof id === 'number' ? 'usercode' : 'user'}=${id}&recent=1`,
                    bind: {
                        $song: 'recent_score[0].song_id',
                        $difficulty: 'recent_score[0].difficulty',
                    },
                },
                {
                    id: 1,
                    endpoint: 'song/info?songname=$song',
                },
                {
                    id: 2,
                    endpoint: `user/best?${typeof id === 'number' ? 'usercode' : 'user'}=${id}&difficulty=$difficulty&songname=$song`,
                },
            ]),
        };
        const res = await superagent.get(`${config.endpoint}v4/batch`)
            .set('User-Agent', config.useragent).query(params);
        if (res.body.status !== 0) throw new Error(res.body.message);
        if (res.body.content[2].result.status === -6) {
            res.body.content[2].result = {
                status: 0,
                content: res.body.content[0].result.content.recent_score[0],
            };
        }
        return res.body.content.map((i) => (i.result.status === 0 ? i.result.content : i.result.status));
    }

    const getPttArray = (rating) => {
        const strings = rating.toString().split('.');
        if (strings.length === 1) {
            strings[1] = '00';
        }
        return strings;
    };
    function padding(num, length) {
        if ((`${num}`).length >= length) return num;
        return padding(`0${num}`, length);
    }
    const renderScore = (score) => {
        const text = padding(score, 8).toString();
        return [text.substring(0, 2), text.substring(2, 5), text.substring(5, 8)].join("'");
    };
    const parseNumber = (num) => Math.floor(num * 1000) / 1000;
    const getRating = (r) => {
        if (r === -0.01) return 'off';
        if (r >= 12.5) return 6;
        if (r >= 12) return 5;
        if (r >= 11) return 4;
        if (r >= 10) return 3;
        if (r >= 7) return 2;
        if (r >= 3) return 1;
        return 0;
    };

    function ArcaeaB30(user) {
        const colors = ['#0A82BE', '#648C3C', '#501948', '#822328'];
        const getSongPtt = (songId, difficulty) => {
            if (user?.songs[songId]) {
                return user.songs[songId].difficulties.find((v) => v.ratingClass === difficulty)?.ratingReal;
            }
            return '???';
        };
        const style = `${commonStyle}
#app {
    --app-width: 2500px;
    --app-height: 1400px;
    --card-height: 205px;
    --card-width: 328px;
    height: var(--app-height);
    width: var(--app-width);
    overflow: hidden;
    font-family: Kazesawa;
    --text: #ecf0f1;
    background-position: center;
    background-size: cover;
    position: relative;
}
#b30 {
    display: flex;
    flex-wrap: wrap;
    width: calc(0.8 * var(--app-width));
}
.b30-item {
    width: var(--card-width);
    height: var(--card-height);
    margin: 13px;
    position: relative;
    box-shadow: 5px 5px 9px 0px #000000b0;
    overflow: hidden;
}
.b30-item-img {
    height: 100%;
    width: 100%;
    background-position: center;
    background-size: cover;
    filter: blur(4px) brightness(50%);
    overflow: hidden;
    transform: scale(1.03);
    background-color: black;
}
.b30-item main {
    top: 0;
    position: absolute;
    padding: 1rem;
    margin-top: 5px;
    color: var(--text)
}
.b30-item main h1 {
    font-size: 2.5rem;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
    width: calc(var(--card-width) - 2rem);
    height: 3rem;
}
.difficulty-bar {
    right: 0;
    position: absolute;
    top: 0;
    border-color: transparent var(--color);
    border-width: 0 50px 50px 0;
    border-style: solid;
}
#info {
    position: absolute;
    bottom: 0;
    right: 0;
}
.b30-item-score {
    font-size: 2.5rem;
    font-family: Exo;
    margin-top: 0.2rem;
    font-weight: bold;
}
#info-bg {
    transform-origin: right bottom;
    transform: scale(0.7) translateY(300px);
}
#info-white-bg {
    transform: translateX(300px) translateY(-20px);
}
#info *:not([data-skip-absolute]) {
    position: absolute;
    bottom: 0;
    right: 0;
    z-index: 2;
}
#info #username {
    color: white;
    transform: translateX(-50px) translateY(-37px);
    font-size: 3em;
    text-shadow: 2px 2px 6px black;
    text-align: left;
    width: 400px;
}
#info-b30, #info-r10 {
    text-align: right;
    font-size: 2em;
    color: white;
    width: 1000px;
    font-family: "Exo";
}
#info-r10 {
    transform: translateX(-10px) translateY(-110px);
}
#info-b30 {
    transform: translateX(-10px) translateY(-150px);
}
#ptt {
    z-index: 11 !important;
    color: white;
    font-family: "Exo";
    text-shadow: 1px 1px black;
    font-size: 50px;
    text-align: center;
}
#ptt a:nth-child(2) {
    font-size: 40px;
}
#ptt-container {
    transform: translateX(-410px) translateY(-36px);
    width: 200px;
    z-index: 10 !important;
}
#character {
    right: -500px !important;
    z-index: 1 !important;
}
main h3 {
    margin-top:1rem; font-size: 1.5rem;
}
main img {
    transform: translateX(-450px);
}`;
        return (
            <div id="app" style={{ backgroundImage: `url(${root}/img/world/3.jpg)` }}>
                <style>{style}</style>
                <div> <div id="b30">
                    {user.b30.best30_list.map((item) => (
                        <div className="b30-item" key={item.song_id}>
                            <div className="b30-item-img"
                                style={{
                                    backgroundImage: `url(${root}/songs/${item.song_id}/base.jpg), url(${root}/songs/dl_${item.song_id}/base.jpg)`,
                                }} />
                            <div className="difficulty-bar" style={{ '--color': colors[item.difficulty] } as any} />
                            <main>
                                <h1>{user.songs[item.song_id]?.title_localized.en || '???'}</h1>
                                <h2 className="b30-item-score">{renderScore(item.score)}</h2>
                                <h2 style={{ fontSize: '1.5rem' }}>
                                    Potential: {getSongPtt(item.song_id, item.difficulty)} &gt; {parseNumber(item.rating)}
                                </h2>
                                <h3>
                                    P:{item.perfect_count} (+{item.shiny_perfect_count})
                                    F:{item.near_count} L:{item.miss_count}
                                </h3>
                            </main>
                        </div>
                    ))}
                </div> </div>
                <div id="info">
                    <img id="info-bg" src={`${root}/_/sidedialog_top.png`} />
                    <img id="info-white-bg" src={`${root}/_/card_overlay.png`} />
                    <img id="character" src={`${root}/char/${user.info.character}${user.info.is_char_uncapped ? 'u' : ''}.png`} />
                    <main>
                        <h1 id="username">{user.info.name}</h1>
                        <div id="ptt-container">
                            <p id="ptt" data-skip-absolute>
                                {user.info.rating !== -1
                                    ? <>
                                        <a data-skip-absolute>{getPttArray(user.info.rating / 100)[0]}.</a>
                                        <a data-skip-absolute>{getPttArray(user.info.rating / 100)[1]}</a>
                                    </>
                                    : '-'}
                            </p>
                        </div>
                        <h1 id="info-b30">Best 30 Average: {user.b30.best30_avg}</h1>
                        <h1 id="info-r10">Recent 10 Average: {user.b30.recent10_avg}</h1>
                        <img src={`${root}/img/rating_${getRating(user.info.rating / 100)}.png`}></img>
                    </main>
                </div>
            </div>
        );
    }

    function ArcaeaRecent({ info, song, highscore }) {
        const style = `${commonStyle}
#main {
    position: absolute;
    width: 1280px;
    height: 720px;
    overflow: hidden;
}

b {
    font-size: 27px;
    position: absolute;
}

#recent-text {
    top: 10px;
    left: 9px;
    color: #895D78FF;
}

#username {
    top: 10px;
    color: #895D78FF;
    right: 675px;
}

#uid-text {
    top: 12px;
    left: 960px;
    color: #FFFFFFFF;
    font-weight: 800;
    -webkit-text-stroke: 1px #8F8F8FFF;
}

#status_bg {
    position: absolute;
    top: 12px;
    left: 915px;
}

#rating {
    position: absolute;
    top: -43px;
    left: 717px;
    width: 160px;
}

#char_icon {
    position: absolute;
    top: -10px;
    width: 100px;
    left: 620px;
}

#ptt_text {
    position: absolute;
    top: 12px;
    left: 754px;
}

#keep_text {
    position: absolute;
    top: 46px;
    left: 750px;
}

#about {
    position: absolute;
    left: 43px;
    top: 230px;
    font-size: larger;
    font-weight: 600;
    color: gray;
}

#difficulty {
    position: absolute;
    left: 43px;
    top: 260px;
    font-size: larger;
    font-weight: 600;
    color: #618A3CFF;
}

#song {
    position: absolute;
    left: 39px;
    top: 289px;
    height: 360px;
}

#hp_base {
    z-index: 0;
    position: absolute;
    left: 394px;
    top: 289px;
    height: 381px;
}

#hp_container {
    z-index: 3;
    overflow: hidden;
    position: absolute;
    left: 400px;
    width: 31px;
    bottom: 71px;
}

#hp_container img {
    z-index: 4;
    position: absolute;
    left: 0px;
    width: 31px;
    bottom: 0px;
    height: 360px;
}

#hp_container p {
    z-index: 5;
    position: absolute;
    color: white;
    left: 6px;
    top: 5px;
}

#hp_overlay {
    z-index: 99;
    position: absolute;
    left: 400px;
    width: 31px;
    top: 289px;
    height: 360px;
    background: repeating-linear-gradient(45deg, rgba(0, 0, 0, 0), rgba(1, 1, 1, 1), 5px,
        );
}

#score_bg {
    position: absolute;
    left: 430px;
    top: 287px;
    z-index: 1;
}

#score {
    position: absolute;
    left: 510px;
    top: 303px;
    font-size: 60px;
    color: white;
    font-family: "Kazesawa";
    z-index: 2;
}

#highscore {
    position: absolute;
    left: 650px;
    top: 379px;
    font-size: 28px;
    font-weight: 1px;
    color: white;
    font-family: "Kazesawa";
    z-index: 2;
}

#score_level {
    position: absolute;
    left: 555px;
    top: 407px;
    font-size: 60px;
    color: white;
    font-family: "Kazesawa";
    z-index: 2;
}

#char {
    position: absolute;
    right: -450px;
    width: 1150px;
    bottom: -480px;
}

#title {
    position: relative;
    color: white;
    top: -605px;
    text-align: center;
    font-size: 50px;
}

#subtitle {
    position: relative;
    color: white;
    top: -600px;
    text-align: center;
    font-size: 30px;
}

#score_banner_text {
    position: absolute;
    top: 205px;
    left: 210px;
    font-size: 30px;
    z-index: 1;
}

#pure {
    position: absolute;
    color: #3298C9FF;
    top: 540px;
    left: 590px;
    font-size: x-large;
    font-weight: 500;
}

#far {
    position: absolute;
    color: #686868FF;
    top: 575px;
    left: 606px;
    font-size: x-large;
    font-weight: 500;
}

#lost {
    position: absolute;
    color: #686868FF;
    top: 610px;
    left: 592px;
    font-size: x-large;
    font-weight: 500;
}

#purecount {
    position: absolute;
    top: 535px;
    left: 700px;
    font-size: xx-large;
    font-weight: 500;
    color: gray;
    text-shadow: white 0 0 5px;
}

#farcount {
    position: absolute;
    top: 570px;
    left: 700px;
    font-size: xx-large;
    font-weight: 500;
    color: gray;
    text-shadow: white 0 0 5px;
}

#lostcount {
    position: absolute;
    top: 605px;
    left: 700px;
    font-size: xx-large;
    font-weight: 500;
    color: gray;
    text-shadow: white 0 0 5px;
}

#ptt p:nth-child(1) {
    z-index: 10;
    position: absolute;
    top: 55px;
    right: 580px;
    color: white;
    font-family: "Exo";
    text-shadow: 1px 1px black;
    font-size: 30px;
    text-align: center;
}

#ptt p:nth-child(2) {
    z-index: 10;
    color: white;
    position: absolute;
    top: 63px;
    left: 700px;
    font-size: 20px;
    font-family: "Exo";
    text-shadow: 1px 1px black;
    text-align: center;
}

#pttimage {
    position: absolute;
    left: 660px;
    top: 35px;
    width: 80px;
}`;
        const recent = info.recent_score[0];
        const diffMap = ['Past', 'Present', 'Future', 'Beyond'];
        const ptt = 0; // TODO
        return (
            <div id="main">
                <style>{style}</style>
                <nav>
                    <img id="head" src={`${root}/layouts/topbar/top_bar_bg.png`} width="1280px" height="72px" />
                    <b id="recent-text">最近</b>
                    <b id="username">{info.name}</b>
                    <img id="status_bg" src={`${root}/layouts/topbar/status_bg.png`} />
                    <b id="uid-text">{info.code}</b>
                    <img id="char_icon" src={`${root}/char/${info.character}_icon.png`} />
                    {/* <p id="ptt">
                        {info.rating !== -1
                            ? <>
                                <p>{getPttArray(info.rating / 100)[0]}.</p>
                                <p>{getPttArray(info.rating / 100)[1]}</p>
                            </>
                            : '-'}
                    </p> */}
                    <img id="pttimage" src={`${root}/img/rating_${getRating(info.rating / 100)}.png`} />
                    {ptt === 0 && (
                        <>
                            <img id="rating" src={`${root}/layouts/results/rating_keep.png`} />
                            <img id="ptt_text" src={`${root}/layouts/results/potentialtext.png`} width="84px" />
                            <img id="keep_text" src={`${root}/layouts/results/keeptext.png`} />
                        </>
                    )}
                </nav>
                <img id="banner" src={`${root}/layouts/results/res_banner.png`} />
                <p id="title">{song.title_localized.en}</p>
                <p id="subtitle">{song.artist}</p>
                <img id="score_bg" src={`${root}/layouts/results/res_scoresection${recent.score >= highscore.score ? '_high' : ''}.png`} />
                <p id="score">{renderScore(recent.score)}</p>
                <p id="highscore">{renderScore(highscore.score)}</p>
                <img id="score_level" src={
                    `${root}/img/grade_${recent.score < 8600000 ? 'd'
                        : recent.score < 8900000 ? 'c'
                            : recent.score < 9200000 ? 'b'
                                : recent.score < 9500000 ? 'a'
                                    : recent.score < 9800000 ? 'aa'
                                        : recent.score < 9900000 ? 'ex'
                                            : 'ex+'}.png`
                } />
                <img id="score_banner_text" src={`${root}/img/clear_${(!recent.miss_count && !recent.near_count) ? 'pure'
                    : !recent.miss_count ? 'full'
                        : recent.health >= 70 ? 'normal' : 'fail'
                }.png`
                } />
                <p id="about">Generated by HydroBot</p>
                <p id="difficulty">{diffMap[recent.difficulty]} {song.difficulties[recent.difficulty].rating}</p>
                <img id="song" src={`${root}/songs/${song.id}/base.jpg`} />
                <img id="hp_base" src={`${root}/layouts/ingame/hp_base.png`} />
                <div id="hp_container" style={{ height: 3.6 * recent.health }}>
                    <img src={`${root}/layouts/ingame/hp_bar.png`} />
                    <p>{recent.health}</p>
                </div>
                <div id="hp_overlay" />
                <img id="char" src={`${root}/char/${info.character}.png`} />
                <p id="pure">PURE</p>
                <p id="purecount">{recent.perfect_count}</p>
                <p id="far">FAR</p>
                <p id="farcount">{recent.near_count}</p>
                <p id="lost">LOST</p>
                <p id="lostcount">{recent.miss_count}</p>
            </div>
        );
    }

    ctx.command('arcaea');

    ctx.command('arcaea.b30 [id:string]', '获取arcaea b30信息', { minInterval: 30000 })
        .shortcut('a b30', { fuzzy: true })
        .userFields(['arcId'])
        .action(async ({ session }, id) => {
            id = id || session.user.arcId;
            if (!id) return '缺少用户ID。';
            const p = ctx.puppeteer.page();
            const result = await getB30(id);
            if (result[0] === -1) return '非法的好友码。';
            if (result[0] === -6) return '没有游玩记录。';
            if (typeof result[0] === 'number') return `查询失败。（${result[0]}）`;
            const info = result[1];
            session.user.arcId = info.user_id;
            const b30 = result[0];
            result.shift();
            result.shift();
            const songs = {};
            for (const song of result) songs[song.id] = song;
            const html = DomServer.renderToString(<ArcaeaB30 info={info} b30={b30} songs={songs} />);
            const page = await p;
            writeFile(tmp`a.html`, html);
            await page.setViewport({
                height: 1400,
                width: 2500,
            });
            await page.goto(`file://${tmp`a.html`}`);
            const img = await page.screenshot({ encoding: 'base64', type: 'jpeg' });
            page.close();
            return s.image(`base64://${img}`);
        });

    ctx.command('arcaea.recent [id:string]', '获取arcaea recent信息', { minInterval: 30000 })
        .shortcut('a recent', { fuzzy: true })
        .userFields(['arcId'])
        .action(async ({ session }, id) => {
            id = id || session.user.arcId;
            if (!id) return '缺少用户ID。';
            const p = ctx.puppeteer.page();
            const result = await getRecent(id);
            if (result[0] === -1) return '非法的好友码。';
            if (result[0] === -6) return '没有游玩记录。';
            if (typeof result[0] === 'number') return `查询失败。（${result[0]}）`;
            const info = result[0];
            session.user.arcId = info.user_id;
            const html = DomServer.renderToString(<ArcaeaRecent info={info} song={result[1]} highscore={result[2]} />);
            const page = await p;
            writeFile(tmp`b.html`, html);
            await page.setViewport({
                height: 720,
                width: 1280,
            });
            await page.goto(`file://${tmp`b.html`}`);
            const img = await page.screenshot({ encoding: 'base64', type: 'jpeg' });
            page.close();
            return s.image(`base64://${img}`);
        });

    ctx.command('arcaea.update <type> <url>', '更新', { authority: 4 })
        .action(async (_, type, url) => {
            const file = tmp`update`;
            const w = createWriteStream(file);
            superagent.get(url).pipe(w);
            await new Promise((resolve, reject) => {
                w.on('finish', () => {
                    console.log('File saved');
                    resolve(null);
                });
                w.on('error', (err) => {
                    console.log('error in request');
                    reject(new Error(`下载失败: ${err.message}`));
                });
            });
            await rename(file, assets`arc.${type}`);
            init();
            return '更新资源完成。';
        });
}
