import { execSync } from 'child_process';
import { nanoid } from 'nanoid';
import { createWriteStream, readFileSync, unlink } from 'fs-extra';
import { Context, s, segment } from 'koishi-core';
import { tmpdir } from 'os';
import path from 'path';
import superagent from 'superagent';
import scribble from 'scribbletune';
import assert from 'assert';

interface Music {
    _id: string,
    pattern: string,
    accent: string,
    bpm: number,
    notes: string,
}
declare module 'koishi-core' {
    interface Tables {
        music: Music,
    }
}

const name = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
const notation = ['1', '1#', '2', '2#', '3', '4', '4#', '5', '5#', '6', '6#', '7'];
const sig = {
    '#': 1, b: -1, '+': 12, '-': -12,
};
const CENTER_C = 4;
function getOffset(expr: string) {
    const [num, m_name] = expr.split('=');
    let i = notation.indexOf(num[0]);
    let j = name.indexOf(m_name[0]);
    assert(i >= 0 && j >= 0);
    i += sig.hasOwnProperty(num.slice(1)) ? sig[num.slice(1)] : 0;
    j += sig.hasOwnProperty(m_name.slice(1)) ? sig[m_name.slice(1)] : 0;
    let offset = j - i;
    if (offset < -6) offset += 12;
    else if (offset > 6) offset -= 12;
    return offset;
}

function _process(input: string) {
    const args = input.split(' ');
    let offset = 0;
    if (args[0].includes('=')) {
        offset = getOffset(args[0]);
        args.shift();
    }
    const str = args.join(' ');
    if (!str.trim()) return ['', ''];
    const pattern = [];
    const notes = [];
    let prev = 0;
    console.log(str);
    for (let index = 0; index <= str.length; index++) {
        const ch = str[index];
        console.log('scanner', index, str.length, ch);
        if (ch === '[' || ch === ']') pattern.push(ch);
        else if (ch === '.' || ch === '_') pattern.push(prev === 0 ? '-' : '_');
        else if (ch === '0') {
            prev = 0;
            pattern.push('-');
        } else if ('1234567'.includes(ch)) {
            prev = +ch;
            pattern.push('x');
            let i = notation.indexOf(ch) + offset;
            while ('b#-+'.includes(str[index + 1])) {
                index++;
                i += sig[str[index]];
            }
            const [oct, tone] = [Math.floor(i / 12), ((i % 12) + 12) % 12];
            notes.push(name[tone] + (CENTER_C + oct));
        }
    }
    return [pattern.join(''), notes.join(' ')];
}

function processer(input: string) {
    const items = input.split('/');
    let pattern = '';
    let notes = '';
    for (let i = 0; i < items.length; i++) {
        const v = items[i]?.trim();
        if (!v) continue;
        console.log(i, v);
        const [p, n] = _process(v);
        if (!p.trim() || !n.trim()) continue;
        pattern += p;
        notes += n;
        if (i < items.length - 1) {
            pattern += '/';
            notes += ' / ';
        }
    }
    return [pattern, notes];
}

export function apply(ctx: Context) {
    ctx.command('music <name:text>', '阴乐！', { minInterval: 10000 });
    async function search(keyword: string) {
        const res = await superagent.post('https://api.sayobot.cn/?post')
            .send({
                cmd: 'beatmaplist',
                limit: 25,
                offset: 0,
                type: 'search',
                keyword,
            });
        if (!res.body.results) return [''];
        let max = 0;
        let sid = '';
        for (const song of res.body.data) {
            if (song.play_count > max) {
                max = song.play_count;
                sid = song.sid;
            }
        }
        const a = await superagent.get(`https://api.sayobot.cn/v2/beatmapinfo?0=${sid}`);
        return [sid, JSON.parse(a.text).data.bid_data[0].audio];
    }

    ctx.command('music.preview <keyword:text>')
        .action(async (_, keyword) => {
            const [sid] = await search(keyword);
            if (!sid) return '没有搜索到歌曲。';
            return s.audio(`https://cdnx.sayobot.cn:25225/preview/${sid}.mp3`);
        });

    ctx.command('music.get <keyword:text>')
        .alias('小夜点歌')
        .action(async (_, keyword) => {
            const [sid, name] = await search(keyword);
            if (!sid) return '没有搜索到歌曲。';
            return s.audio(`https://dl.sayobot.cn/beatmaps/files/${sid}/${name}`);
        });

    ctx.on('connect', async () => {
        const coll = ctx.database.mongo.collection('music');

        ctx.command('music.gen [notes:text]')
            .alias('musicgen')
            .option('save', '-s')
            .option('load', '-l <id:string>')
            .option('pattern', '-p <pattern:string>')
            .option('accent', '-a <accent:string>')
            .option('bpm', '-b <bpm:number>', { fallback: 100 })
            .option('base', '-B <base:number>', { fallback: 4 })
            .option('sizzle', '-S <sizzle:string>')
            .action(async ({ session, options }, notes) => {
                if (options.save) {
                    const res = await coll.insertOne({
                        _id: nanoid(8), pattern: options.pattern, accent: options.accent, bpm: options.bpm, notes,
                    });
                    return `已保存，ID = ${res.insertedId}`;
                }
                if (options.load) {
                    const res = await coll.findOne({ _id: options.load });
                    options.accent = res.accent;
                    options.bpm = res.bpm;
                    options.pattern = res.pattern;
                    notes = res.notes;
                }
                if (notes.startsWith('http')) {
                    const res = await superagent.get(notes);
                    if (res.text) notes = res.text;
                    else {
                        const w = createWriteStream('/tmp/1');
                        superagent.get(notes).pipe(w);
                        await new Promise((resolve, reject) => {
                            w.on('finish', resolve);
                            w.on('error', reject);
                        });
                        notes = readFileSync('/tmp/1', 'utf-8');
                    }
                }
                if (!notes) return '没有找到供演奏的音符。';
                const tracks = [];
                if (!options.pattern) [options.pattern, notes] = processer(notes.decode());
                if (!notes?.length) return '没有找到供演奏的音符。';
                const _notes = ` ${notes} `
                    .replace(/ /g, '  ')
                    .replace(/ 1-- /g, ` C${options.base - 2} `)
                    .replace(/ 2-- /g, ` D${options.base - 2} `)
                    .replace(/ 3-- /g, ` E${options.base - 2} `)
                    .replace(/ 4-- /g, ` F${options.base - 2} `)
                    .replace(/ 5-- /g, ` G${options.base - 2} `)
                    .replace(/ 6-- /g, ` A${options.base - 2} `)
                    .replace(/ 7-- /g, ` B${options.base - 2} `)
                    .replace(/ 1b-- /g, ` Cb${options.base - 2} `)
                    .replace(/ 2b-- /g, ` Db${options.base - 2} `)
                    .replace(/ 3b-- /g, ` Eb${options.base - 2} `)
                    .replace(/ 4b-- /g, ` Fb${options.base - 2} `)
                    .replace(/ 5b-- /g, ` Gb${options.base - 2} `)
                    .replace(/ 6b-- /g, ` Ab${options.base - 2} `)
                    .replace(/ 7b-- /g, ` Bb${options.base - 2} `)
                    .replace(/ 1#-- /g, ` C#${options.base - 2} `)
                    .replace(/ 2#-- /g, ` D#${options.base - 2} `)
                    .replace(/ 3#-- /g, ` E#${options.base - 2} `)
                    .replace(/ 4#-- /g, ` F#${options.base - 2} `)
                    .replace(/ 5#-- /g, ` G#${options.base - 2} `)
                    .replace(/ 6#-- /g, ` A#${options.base - 2} `)
                    .replace(/ 7#-- /g, ` B#${options.base - 2} `)
                    .replace(/ 1- /g, ` C${options.base - 1} `)
                    .replace(/ 2- /g, ` D${options.base - 1} `)
                    .replace(/ 3- /g, ` E${options.base - 1} `)
                    .replace(/ 4- /g, ` F${options.base - 1} `)
                    .replace(/ 5- /g, ` G${options.base - 1} `)
                    .replace(/ 6- /g, ` A${options.base - 1} `)
                    .replace(/ 7- /g, ` B${options.base - 1} `)
                    .replace(/ 1b- /g, ` Cb${options.base - 1} `)
                    .replace(/ 2b- /g, ` Db${options.base - 1} `)
                    .replace(/ 3b- /g, ` Eb${options.base - 1} `)
                    .replace(/ 4b- /g, ` Fb${options.base - 1} `)
                    .replace(/ 5b- /g, ` Gb${options.base - 1} `)
                    .replace(/ 6b- /g, ` Ab${options.base - 1} `)
                    .replace(/ 7b- /g, ` Bb${options.base - 1} `)
                    .replace(/ 1#- /g, ` C#${options.base - 1} `)
                    .replace(/ 2#- /g, ` D#${options.base - 1} `)
                    .replace(/ 3#- /g, ` E#${options.base - 1} `)
                    .replace(/ 4#- /g, ` F#${options.base - 1} `)
                    .replace(/ 5#- /g, ` G#${options.base - 1} `)
                    .replace(/ 6#- /g, ` A#${options.base - 1} `)
                    .replace(/ 7#- /g, ` B#${options.base - 1} `)
                    .replace(/ 1 /g, ` C${options.base} `)
                    .replace(/ 2 /g, ` D${options.base} `)
                    .replace(/ 3 /g, ` E${options.base} `)
                    .replace(/ 4 /g, ` F${options.base} `)
                    .replace(/ 5 /g, ` G${options.base} `)
                    .replace(/ 6 /g, ` A${options.base} `)
                    .replace(/ 7 /g, ` B${options.base} `)
                    .replace(/ 1b /g, ` Cb${options.base} `)
                    .replace(/ 2b /g, ` Db${options.base} `)
                    .replace(/ 3b /g, ` Eb${options.base} `)
                    .replace(/ 4b /g, ` Fb${options.base} `)
                    .replace(/ 5b /g, ` Gb${options.base} `)
                    .replace(/ 6b /g, ` Ab${options.base} `)
                    .replace(/ 7b /g, ` Bb${options.base} `)
                    .replace(/ 1# /g, ` C#${options.base} `)
                    .replace(/ 2# /g, ` D#${options.base} `)
                    .replace(/ 3# /g, ` E#${options.base} `)
                    .replace(/ 4# /g, ` F#${options.base} `)
                    .replace(/ 5# /g, ` G#${options.base} `)
                    .replace(/ 6# /g, ` A#${options.base} `)
                    .replace(/ 7# /g, ` B#${options.base} `)
                    .replace(/ 1\+ /g, ` C${options.base + 1} `)
                    .replace(/ 2\+ /g, ` D${options.base + 1} `)
                    .replace(/ 3\+ /g, ` E${options.base + 1} `)
                    .replace(/ 4\+ /g, ` F${options.base + 1} `)
                    .replace(/ 5\+ /g, ` G${options.base + 1} `)
                    .replace(/ 6\+ /g, ` A${options.base + 1} `)
                    .replace(/ 7\+ /g, ` B${options.base + 1} `)
                    .replace(/ 1b\+ /g, ` Cb${options.base + 1} `)
                    .replace(/ 2b\+ /g, ` Db${options.base + 1} `)
                    .replace(/ 3b\+ /g, ` Eb${options.base + 1} `)
                    .replace(/ 4b\+ /g, ` Fb${options.base + 1} `)
                    .replace(/ 5b\+ /g, ` Gb${options.base + 1} `)
                    .replace(/ 6b\+ /g, ` Ab${options.base + 1} `)
                    .replace(/ 7b\+ /g, ` Bb${options.base + 1} `)
                    .replace(/ 1#\+ /g, ` C#${options.base + 1} `)
                    .replace(/ 2#\+ /g, ` D#${options.base + 1} `)
                    .replace(/ 3#\+ /g, ` E#${options.base + 1} `)
                    .replace(/ 4#\+ /g, ` F#${options.base + 1} `)
                    .replace(/ 5#\+ /g, ` G#${options.base + 1} `)
                    .replace(/ 6#\+ /g, ` A#${options.base + 1} `)
                    .replace(/ 7#\+ /g, ` B#${options.base + 1} `)
                    .replace(/ 1\+\+ /g, ` C${options.base + 2} `)
                    .replace(/ 2\+\+ /g, ` D${options.base + 2} `)
                    .replace(/ 3\+\+ /g, ` E${options.base + 2} `)
                    .replace(/ 4\+\+ /g, ` F${options.base + 2} `)
                    .replace(/ 5\+\+ /g, ` G${options.base + 2} `)
                    .replace(/ 6\+\+ /g, ` A${options.base + 2} `)
                    .replace(/ 7\+\+ /g, ` B${options.base + 2} `)
                    .replace(/ 1b\+\+ /g, ` Cb${options.base + 2} `)
                    .replace(/ 2b\+\+ /g, ` Db${options.base + 2} `)
                    .replace(/ 3b\+\+ /g, ` Eb${options.base + 2} `)
                    .replace(/ 4b\+\+ /g, ` Fb${options.base + 2} `)
                    .replace(/ 5b\+\+ /g, ` Gb${options.base + 2} `)
                    .replace(/ 6b\+\+ /g, ` Ab${options.base + 2} `)
                    .replace(/ 7b\+\+ /g, ` Bb${options.base + 2} `)
                    .replace(/ 1#\+\+ /g, ` C#${options.base + 2} `)
                    .replace(/ 2#\+\+ /g, ` D#${options.base + 2} `)
                    .replace(/ 3#\+\+ /g, ` E#${options.base + 2} `)
                    .replace(/ 4#\+\+ /g, ` F#${options.base + 2} `)
                    .replace(/ 5#\+\+ /g, ` G#${options.base + 2} `)
                    .replace(/ 6#\+\+ /g, ` A#${options.base + 2} `)
                    .replace(/ 7#\+\+ /g, ` B#${options.base + 2} `)
                    .replace(/ {2}/g, ' ')
                    .split('/');
                const _accents = options.accent ? options.accent.split('/') : [];
                const _patterns = options.pattern ? options.pattern.decode().split('/') : [];
                const _sizzles = options.sizzle ? options.sizzle.decode().split('/') : [];
                console.log(_notes);
                for (const i in _notes) {
                    let [note, random] = _notes[i].split('~').map((i) => (i ? i.trim() : ''));
                    const accent = _accents[i];
                    let pattern = _patterns[i];
                    const sizzle = _sizzles[i];
                    if (note.startsWith('ARP(') && note.endsWith(')')) {
                        const inner = note.split('ARP(')[1].split(')')[0];
                        const params = inner.split(',').map((i) => i.trim());
                        note = scribble.arp({
                            chords: params[0],
                            order: params[1],
                            count: params[2] ? +params[2] : 1,
                        });
                    }
                    if (note.startsWith('SCALE(') && note.endsWith(')')) {
                        const inner = note.split('SCALE(')[1].split(')')[0];
                        note = scribble.scale(inner);
                    }
                    if (random) {
                        if (random.startsWith('ARP(') && random.endsWith(')')) {
                            const inner = random.split('ARP(')[1].split(')')[0];
                            const params = inner.split(',').map((i) => i.trim());
                            random = scribble.arp({
                                chords: params[0],
                                order: params[1],
                                count: params[2] ? +params[2] : 1,
                            });
                        }
                        if (random.startsWith('SCALE(') && random.endsWith(')')) {
                            const inner = random.split('SCALE(')[1].split(')')[0];
                            random = scribble.scale(inner);
                        }
                    }
                    if (!pattern) pattern = 'x'.repeat(note.split(' ').length);
                    const config: any = {
                        notes: note,
                        pattern,
                        accent,
                    };
                    if (sizzle) config.sizzle = sizzle;
                    if (random) config.randomNotes = random;
                    const clip = scribble.clip(config);
                    const id = Math.random().toString();
                    const mid = path.resolve(tmpdir(), `${id}.mid`);
                    const wav = path.resolve(tmpdir(), `${id}.wav`);
                    scribble.midi(clip, mid, options.bpm);
                    execSync(`timidity ${mid} -Ow -o ${wav}`);
                    tracks.push(wav);
                    // eslint-disable-next-line no-await-in-loop
                    await unlink(mid);
                }
                while (tracks.length > 1) {
                    const id = Math.random().toString();
                    const tmp = path.resolve(tmpdir(), `${id}.wav`);
                    execSync(`ffmpeg -i ${tracks[0]} -i ${tracks[1]} -filter_complex amix=inputs=2:duration=longest ${tmp}`);
                    // eslint-disable-next-line no-await-in-loop
                    await Promise.all([
                        unlink(tracks[0]),
                        unlink(tracks[1]),
                    ]);
                    tracks[1] = tmp;
                    tracks.shift();
                }
                if (session.platform === 'discord') {
                    const id = Math.random().toString();
                    const tmp = path.resolve(tmpdir(), `${id}.mp3`);
                    execSync(`ffmpeg -i ${tracks[0]} -f mp2 ${tmp}`);
                    await session.send(segment.audio(`file://${tmp}`));
                } else {
                    await session.send(segment.audio(`file://${tracks[0]}`));
                }
                await unlink(tracks[0]);
            });
    });
}
