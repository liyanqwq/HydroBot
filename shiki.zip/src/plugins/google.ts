import { google } from 'googleapis';
import HttpsProxyAgent from 'https-proxy-agent';
import { Context } from 'koishi-core';

const scopes = 'https://www.googleapis.com/auth/analytics.readonly';

interface Config {
    resId: string;
    privateKey: string;
    mail: string;
    proxy: string;
}

export async function apply(ctx: Context, config: Config) {
    ctx.command('hydro', 'Hydro').action(({ session }) => session.execute('hydro -h'));
    ctx.command('hydro/bzoj', 'Hydro BZOJ').action(({ session }) => session.execute('bzoj -h'));
    ctx.command('hydro/bzoj.hot', 'BZOJ今日热门题目', { minInterval: 60000 })
        .action(async () => {
            const jwt = new google.auth.JWT({
                email: config.mail,
                scopes,
                key: config.privateKey,
            });
            await jwt.authorize();
            const analytics = google.analytics({
                version: 'v3',
                auth: jwt,
                agent: HttpsProxyAgent(config.proxy),
            });
            const { data } = await analytics.data.ga.get({
                ids: config.resId,
                'start-date': 'yesterday',
                'end-date': 'today',
                metrics: 'ga:uniquePageviews',
                dimensions: 'ga:pagePath',
                sort: '-ga:uniquePageviews',
                'max-results': 1000,
            });
            const inf = data.rows.map((i) => {
                if (!i[0].startsWith('/d/bzoj/')) return;
                const pid = /^\/d\/bzoj\/p\/(\d+)$/.exec(i[0])?.[1];
                return pid ? [+pid, +i[1]] : null;
            }).filter((i) => !!i);
            return `今日热门题目： P${inf[0][0]} P${inf[1][0]} P${inf[2][0]}`;
        });
}
