import { Context, Channel, User } from 'koishi-core';
import * as KoishiPluginEval from 'koishi-plugin-eval';
import { s, segment, sleep } from 'koishi-utils';
import { text2png } from '../lib/graph';

declare module 'koishi-core' {
    interface Session {
        __sendCount?: number
    }
}

export function apply(ctx: Context, config: KoishiPluginEval.Config) {
    ctx.plugin(KoishiPluginEval, config);

    ctx.on('eval/before-send', async (content, session) => {
        session.__sendCount = (session.__sendCount || 0) + 1;
        if (session.__sendCount > 3) return '';
        const msg = segment.parse(content).filter((i) => i.type === 'text').map((i) => i.data.content).join('');
        if (msg.length > 512) {
            const page = await ctx.puppeteer.page();
            const res = await text2png(page, content.decode());
            return s('image', { file: `base64://${res}` });
        }
        return content;
    });

    ctx.command('evaluate')
        .option('i', 'Output as image', { hidden: true })
        .userFields(User.fields)
        .channelFields(Channel.fields)
        .check(({ session }) => {
            if (!session._sudo) return;
            const cmd = session.argv.args[0].replace('eval ', '');
            // @ts-ignore
            if (session.argv.options.i) session.execute(`_.eval -i ${cmd}`);
            session.execute(`_.eval ${cmd}`);
            return '';
        });

    ctx.command('API <name> [arg0] [arg1] [arg2] [arg3]', { authority: 5 })
        .action(async ({ session }, name, ...args) => {
            const res = await session.bot[name](...args);
            return JSON.stringify(res);
        });

    ctx.command('@', 'utils', { hidden: true });
    ctx.command('@.silent <command:text>', { hidden: true })
        .action(({ session }, command) => session.executeSilent(command));
    ctx.command('@.sleep <duration> <command:text>', { hidden: true })
        .action(async ({ session }, _duration, command) => {
            let duration = Math.min(10000, +_duration);
            if (Number.isNaN(duration) || !duration) duration = 0;
            await sleep(duration);
            await session.execute(command);
        });
}
