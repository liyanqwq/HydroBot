/* eslint-disable no-empty-function */
// @ts-nocheck
import crypto from 'crypto';
import * as superagent from 'superagent';
import proxy from 'superagent-proxy';
import { App, Platform, Session } from 'koishi-core';
import { Logger, s, segment } from 'koishi-utils';
import { JSDOM } from 'jsdom';
import type { Browser } from 'puppeteer';

proxy(superagent);
const logger = new Logger('github');
class InvalidTokenError extends Error { }
interface GithubToken {
    access_token: string,
    refresh_token: string,
}
interface Subscription {
    _id: string,
    target: string[],
}
interface EventHandler {
    merge: boolean;
    hook?: (body: any) => Promise<[string?, Record<string, any>?]>
    interact?: (message: string, session: Session, event: any, getToken: () => Promise<string>) => Promise<[string?, Record<string, any>?] | boolean>
}
declare module 'koishi-core' {
    interface User {
        GithubToken: GithubToken
    }
    interface Tables {
        github_watch: Subscription,
        github_data: any
    }
}
function formatMarkdown(source: string) {
    return source
        .replace(/^```(.*)$/gm, '')
        .replace(/^<!--(.*)-->$/gm, '')
        .replace(/\n\s*\n/g, '\n')
        .replace(/(\r?\n *)+/gmi, '\n');
}
function sha256(str: string): string {
    return crypto.createHash('sha256')
        .update(str)
        .digest('hex');
}

async function screenshot(browser: Browser, url: string, selector: string, offset: number[]) {
    const page = await browser.page();
    try {
        await page.goto(url, { waitUntil: 'networkidle0' });
        const el = await page.$(selector);
        let clip = await el.boundingBox();
        await page.setViewport({
            height: Math.ceil(clip.y + clip.height + 50),
            width: 1080,
        });
        clip = await el.boundingBox();
        clip = {
            x: clip.x - offset[0],
            y: clip.y - offset[1],
            width: clip.width + offset[2],
            height: clip.height + offset[3],
        };
        const base64 = await page.screenshot({
            encoding: 'base64',
            type: 'jpeg',
            clip,
        });
        await page.close();
        return base64;
    } catch (error) {
        await page.close();
        throw error;
    }
}

export const apply = (app: App, config: any) => {
    function Get(url: string) {
        return superagent
            .get(url)
            .proxy(config.proxy)
            .set('Accept', 'application/vnd.github.v3+json')
            .set('User-Agent', 'HydroBot');
    }

    function Post(url: string) {
        return superagent
            .post(url)
            .proxy(config.proxy)
            .set('Accept', 'application/vnd.github.v3+json')
            .set('User-Agent', 'HydroBot');
    }

    function Put(url: string) {
        return superagent
            .put(url)
            .proxy(config.proxy)
            .set('Accept', 'application/vnd.github.v3+json')
            .set('User-Agent', 'HydroBot');
    }

    async function pullRequestInteractor(message: string, session: Session, event, getToken) {
        if (message.includes('!!link')) return [event.link];
        const token = await getToken();
        if (message.includes('!!merge')) {
            const commitMsg = message.split('!!merge')[1];
            await Put(`https://api.github.com/repos/${event.reponame}/pulls/${event.issueId}/merge`)
                .set('Authorization', `token ${token}`)
                .send({ commit_title: commitMsg.trim() });
            return [];
        }
        if (message.includes('!!approve')) {
            await Post(`https://api.github.com/repos/${event.reponame}/pulls/${event.issueId}/reviews`)
                .set('Authorization', `token ${token}`)
                .send({ event: 'APPROVE' });
            return [];
        }
        if (message.includes('!!diff')) {
            const data = await screenshot(app.puppeteer, `${event.link}/files`, '.files-bucket', [0, 0, 0, 0]);
            return [s.image(`base64://${data}`)];
        }
        await Post(`https://api.github.com/repos/${event.reponame}/issues/${event.issueId}/comments`)
            .set('Authorization', `token ${token}`)
            .send({ body: message });
        return [];
    }

    app.on('connect', () => {
        const coll = app.database.mongo.collection('github_watch');
        const collData = app.database.mongo.collection('github_data');

        const events: Record<string, EventHandler> = {
            push: {
                async hook(body) {
                    const ref = body.ref.split('/')[2];
                    const sender = body.head_commit ? body.head_commit.author.username : body.sender.login;
                    let added = 0;
                    let removed = 0;
                    let modified = 0;
                    let resp = `Recent commit to ${body.repository.full_name}${ref === 'master' ? '' : `:${ref}`} by ${sender}`;
                    if (config.sourcegraph) {
                        try {
                            const result = await superagent.post('https://sourcegraph.com/.api/graphql')
                                .set('Authorization', `token ${config.sourcegraph}`)
                                .send({
                                    query: `query{
repository(name:"github.com/${body.repository.full_name}"){
  comparison(base:"${body.before}",head:"${body.after}"){
    fileDiffs{nodes{stat{added changed deleted}}}
  }
}
}`,
                                });
                            if (!result.body.data) logger.info(result.body);
                            else if (!result.body.data.repository) logger.info('Repo not found: %s', body.repository.full_name);
                            else {
                                const changes = result.body.data.repository.comparison.fileDiffs.nodes;
                                for (const change of changes) {
                                    added += change.stat.added || 0;
                                    removed += change.stat.deleted || 0;
                                    modified += change.stat.changed || 0;
                                }
                            }
                        } catch (e) {
                            logger.error(e);
                        }
                    }
                    if (added || removed || modified) resp += `\n${added}+ ${removed}- ${modified}M`;
                    if (body.commits.length < 5) {
                        for (const commit of body.commits) {
                            const det = [];
                            if (commit.added.length) det.push(`${commit.added.length}+`);
                            if (commit.removed.length) det.push(`${commit.removed.length}-`);
                            if (commit.modified.length) det.push(`${commit.modified.length}M`);
                            resp += `\n${commit.id.substr(0, 6)} ${formatMarkdown(commit.message).replace(/\n/g, '\r\n')} (${det.join(' ')})`;
                        }
                    } else {
                        let commit = body.commits[0];
                        let det = [];
                        if (commit.added.length) det.push(`${commit.added.length}+`);
                        if (commit.removed.length) det.push(`${commit.removed.length}-`);
                        if (commit.modified.length) det.push(`${commit.modified.length}M`);
                        resp += `\n${commit.id.substr(0, 6)} ${formatMarkdown(commit.message).replace(/\n/g, '\r\n')} (${det.join(' ')})`;
                        resp += `\n...${body.commits.length - 2} commits omitted...`;
                        commit = body.commits[body.commits.length - 1];
                        det = [];
                        if (commit.added.length) det.push(`${commit.added.length}+`);
                        if (commit.removed.length) det.push(`${commit.removed.length}-`);
                        if (commit.modified.length) det.push(`${commit.modified.length}M`);
                        resp += `\n${commit.id.substr(0, 6)} ${formatMarkdown(commit.message).replace(/\n/g, '\r\n')} (${det.join(' ')})`;
                    }
                    return [resp, { link: body.compare }];
                },
                async interact(message, session, event) {
                    if (message.includes('!!link')) return [event.link];
                    if (message.includes('!!diff')) {
                        const data = await screenshot(app.puppeteer, event.link, '.files-bucket', [0, 0, 0, 0]);
                        return [s.image(`base64://${data}`)];
                    }
                    return [];
                },
            },
            fork: {
                merge: true,
                async hook(body) {
                    if (body.action === 'created') {
                        return [`${body.sender.login} forked ${body.repository.full_name}`];
                    }
                    return [];
                },
            },
            issues: {
                merge: (body) => `${body.repository.full_name}/${body.issue.number}`,
                async hook(body) {
                    let resp;
                    if (body.action === 'opened' || body.action === 'edited') {
                        resp = `${body.sender.login} ${body.action} issue ${body.repository.full_name}#${body.issue.number}`;
                        try {
                            const base64 = await screenshot(
                                app.puppeteer, body.issue.html_url,
                                '.js-discussion',
                                [68, 130, 92, 130],
                            );
                            resp += `\n${segment.image(`base64://${base64}`)}`;
                        } catch (error) {
                            new Logger('puppeteer').warn(error);
                            resp += `\n${formatMarkdown(body.issue.title)}\n${formatMarkdown(body.issue.body || '')}`;
                        }
                    } else if (body.action === 'assigned') {
                        resp = `${body.repository.full_name}#${body.issue.number}: Assigned ${body.assignee.login}`;
                    } else if (body.action === 'unassigned') {
                        resp = `${body.repository.full_name}#${body.issue.number}: Unassigned ${body.assignee.login}`;
                    } else if (body.action === 'closed') {
                        resp = `${body.sender.login} closed ${body.repository.full_name}#${body.issue.number}.`;
                    } else if (['reopened', 'locked', 'unlocked'].includes(body.action)) {
                        resp = `${body.sender.login} ${body.action} Issue:${body.repository.full_name}#${body.issue.number}`;
                    } else if (body.action === 'labeled') {
                        return [];
                        //  resp = `${body.sender.login} labled ${body.repository.full_name}#${body.issue.number} ${body.lable.name}`;
                    } else resp = `Unknown issue action: ${body.action}`;
                    return [
                        resp,
                        {
                            link: body.comment?.html_url || body.issue.html_url,
                            reponame: body.repository.full_name,
                            issueId: body.issue.number,
                        },
                    ];
                },
                async interact(message, session, event, getToken) {
                    if (message.includes('!!link')) return [event.link];
                    const token = await getToken();
                    await Get(`https://api.github.com/repos/${event.reponame}/issues/${event.issueId}/comments`)
                        .set('Authorization', `token ${token}`)
                        .send({ body: message });
                    return [];
                },
            },
            issue_comment: {
                merge: (body) => `${body.repository.full_name}/${body.issue.number}`,
                async hook(body) {
                    let resp;
                    if (body.action === 'created' || body.action === 'edited') {
                        if (body.comment.user.login === 'codecov[bot]') return [];
                        // eslint-disable-next-line max-len
                        resp = `${body.comment.user.login} ${body.action === 'created' ? 'commented' : 'edited a comment'} on ${body.repository.full_name}#${body.issue.number}\n${body.issue.title}`;
                        try {
                            const base64 = await screenshot(
                                app.puppeteer, body.issue.html_url,
                                `#${body.comment.html_url.split('#')[1]}`,
                                [86, 14, 92, 20],
                            );
                            resp += `\n${segment.image(`base64://${base64}`)}`;
                        } catch (error) {
                            new Logger('puppeteer').warn(error);
                            resp += `\n${formatMarkdown(body.comment.body)}`;
                        }
                    }
                    return [
                        resp,
                        {
                            link: body.issue.html_url,
                            reponame: body.repository.full_name,
                            issueId: body.issue.number,
                        },
                    ];
                },
                interact: pullRequestInteractor,
            },
            pull_request: {
                merge: (body) => `${body.repository.full_name}/${body.pull_request.number}`,
                async hook(body) {
                    let resp;
                    const { full_name, owner } = body.repository;
                    const {
                        user, html_url, title, base, head, number, merged,
                    } = body.pull_request;
                    const prefix = new RegExp(`^${owner.login}:`);
                    const baseLabel = base.label.replace(prefix, '');
                    const headLabel = head.label.replace(prefix, '');
                    if (body.action === 'opened') {
                        resp = `${user.login} opened an pull request for ${full_name}#${number}(${baseLabel}<${headLabel})`;
                        try {
                            const base64 = await screenshot(
                                app.puppeteer, html_url,
                                '.js-discussion',
                                [68, 160, 92, 160],
                            );
                            resp += `\n${segment.image(`base64://${base64}`)}`;
                        } catch (error) {
                            new Logger('puppeteer').warn(error);
                            resp += `\n${title}`;
                            resp += `\n${formatMarkdown(body.pull_request.body || '')}`;
                        }
                    } else if (body.action === 'created') {
                        resp = `${user.login} commented on ${full_name}#${number}(${baseLabel}<${headLabel})`;
                        resp += `\n${body.comment.body}`;
                    } else if (body.action === 'assigned') {
                        resp = `${full_name}#${number}: Assigned ${body.assignee.login}`;
                    } else if (body.action === 'unassigned') {
                        resp = `${full_name}#${number}: Unassigned ${body.assignee.login}`;
                    } else if (body.action === 'review_requested') {
                        resp = `${full_name}#${number}: Request a review.`;
                    } else if (body.action === 'closed') {
                        const type = merged ? 'merged' : 'closed';
                        resp = `${body.sender.login} ${type} ${full_name}#${number}(${baseLabel}<${headLabel})`;
                    } else if (['reopened', 'locked', 'unlocked'].includes(body.action)) {
                        resp = `${body.sender.login} ${body.action} PR:${full_name}#${number}`;
                    } else if (['synchronize'].includes(body.action)) {
                        resp = '';
                    } else if (body.action === 'ready_for_review') {
                        resp = `${full_name}#${number} is ready for review.`;
                    } else resp = `Unknown pull request action: ${body.action}`;
                    return [
                        resp,
                        {
                            link: html_url,
                            reponame: full_name,
                            issueId: number,
                        },
                    ];
                },
                interact: pullRequestInteractor,
            },
            pull_request_review: {
                merge: true,
                async hook(body) {
                    if (body.review.state === 'commented') return [];
                    if (body.review.state === 'approved') {
                        return [`${body.sender.login} approved ${body.repository.full_name}#${body.pull_request.number}`];
                    }
                    return [undefined, {
                        link: body.pull_request.html_url,
                        reponame: body.repository.full_name,
                        issueId: body.pull_request.number,
                    }];
                },
                interact: pullRequestInteractor,
            },
            pull_request_review_comment: {
                merge: true,
                async hook(body) {
                    let resp = '';
                    if (body.action === 'created') {
                        resp = `${body.comment.user.login} commented on ${body.repository.full_name}#${body.pull_request.number}\n`;
                        resp += formatMarkdown(body.comment.body);
                    }
                    return [
                        resp,
                        {
                            link: body.pull_request.html_url,
                            reponame: body.repository.full_name,
                            issueId: body.pull_request.number,
                        },
                    ];
                },
                interact: pullRequestInteractor,
            },
            star: {
                merge: true,
                async hook(body) {
                    if (body.action === 'created') {
                        if (await collData.findOne({
                            type: 'star', user: body.sender.login, repo: body.repository.full_name,
                        })) return [];
                        return [
                            `${body.sender.login} starred ${body.repository.full_name} (total ${body.repository.stargazers_count} stargazers)`,
                            { user: body.sender.login, repo: body.repository.full_name },
                        ];
                    }
                    return [];
                },
            },
            watch: {
                merge: true,
                async hook(body) {
                    if (body.action === 'created') {
                        if (await collData.findOne({
                            type: 'watch', user: body.sender.login, repo: body.repository.full_name,
                        })) return [];
                        return [
                            `${body.sender.login} is watching ${body.repository.full_name} (total ${body.repository.watchers_count} watchers)`,
                            { user: body.sender.login, repo: body.repository.full_name },
                        ];
                    }
                    return [];
                },
            },
            project_card: {},
            project_column: {},
            check_run: {},
            check_suite: {},
            workflow_job: {},
            workflow_run: {},
            repository_vulnerability_alert: {},
            status: {},
            label: {},
            deployment_status: {},
            deployment: {},
            page_build: {},
        };

        app.router.post('/github', async (ctx) => {
            try {
                const event = ctx.request.headers['x-github-event'] as string;
                let body;
                if (typeof ctx.request.body.payload === 'string') body = JSON.parse(ctx.request.body.payload);
                else body = ctx.request.body;
                const _id = sha256(JSON.stringify(body));
                if (!events[event]) {
                    events[event] = {
                        hook: (b) => Promise.resolve([`${b.repository.full_name} triggered an unknown event: ${event}`]),
                    };
                }
                if (events[event].hook) {
                    // TODO organization webhook?
                    const reponame = body.repository.full_name;
                    const [message, inf] = await events[event].hook(body);
                    const res = await collData.findOne({ _id });
                    if (!res) {
                        let relativeIds = [];
                        if (message) {
                            const data = await coll.findOne({ _id: reponame.toLowerCase() });
                            if (data) {
                                for (const id of data.target) {
                                    const [platform, gid] = id.split(':');
                                    // eslint-disable-next-line no-await-in-loop
                                    const gdoc = await app.database.getChannel(platform as Platform, gid, ['assignee']);
                                    if (gdoc.assignee && app.bots[`${platform}:${gdoc.assignee}`]) {
                                        relativeIds.push(app.bots[`${platform}:${gdoc.assignee}`].sendMessage(gid, message));
                                    } else logger.warn('Cannot send message to %s:%d with assignee %d', platform, id, gdoc.assignee);
                                }
                            }
                            relativeIds = await Promise.all(relativeIds);
                            await collData.insertOne({
                                _id, type: event, relativeIds, ...inf,
                            });
                        }
                        ctx.body = `Pushed to ${relativeIds.length} group(s)`;
                    } else ctx.body = 'Duplicate event';
                } else ctx.body = 'Event ignored.';
            } catch (e) {
                console.log(e);
                ctx.body = e.toString();
            }
        });

        app.router.get('/github/authorize', async (ctx) => {
            const [platform, id] = (ctx.query.state as string).split(':');
            const code = ctx.query.code;
            const result = await superagent.post('https://github.com/login/oauth/access_token')
                .proxy(config.proxy)
                .send({
                    client_id: config.client_id,
                    client_secret: config.client_secret,
                    code,
                    redirect_uri: config.redirect_uri,
                    state: ctx.query.state,
                });
            if (result.body.access_token) {
                await app.database.setUser(platform as Platform, id, { GithubToken: result.body });
                ctx.body = 'Done';
            } else {
                ctx.body = 'Error';
            }
        });

        app.middleware(async (session, next) => {
            if (session.platform === 'onebot') {
                if (/github\.com\/[a-zA-Z0-9-_.]+\/[a-zA-Z0-9-_.]+/.test(session.content)) {
                    const p = /(github\.com\/[a-zA-Z0-9-_.]+\/[a-zA-Z0-9-_.]+(\/(issues|pull)\/\d+)?)/.exec(session.content)[1];
                    if (session.content.split(p)[1]?.[0] === '/') return next();
                    return session.execute(`github.repo ${p}`);
                }
                if (/^[a-zA-Z0-9-_.]+\/[a-zA-Z0-9-_.]+#\d+/.test(session.content)) {
                    const p = /([a-zA-Z0-9-_.]+\/[a-zA-Z0-9-_.]+)#(\d+)/.exec(session.content);
                    return session.execute(`github.repo github.com/${p[1]}/issues/${p[2]}`);
                }
            }
            if (!session.quote) return next();
            const parsedMsg = session.parsed.content
                .replace(/\[CQ:at,.*\]/g, '')
                .replace(/\[CQ:image,file=(.*)\]/g, (str) => ` ![](${/\[CQ:image,file=(.*)\]/g.exec(str)[1]}) `)
                .decode().trim();
            if (!parsedMsg) return next();
            const [relativeEvent, user] = await Promise.all([
                collData.findOne({ relativeIds: session.quote.messageId }),
                app.database.getUser(session.platform, session.userId, ['GithubToken']),
            ]);
            if (!relativeEvent || !events[relativeEvent.type].interact) return;
            logger.info(parsedMsg);
            logger.info('Reply: %s', relativeEvent);
            if (parsedMsg.startsWith('//')) return next();
            try {
                async function getToken() {
                    if (!user.GithubToken?.access_token) throw new InvalidTokenError();
                    const result = await superagent.get('https://api.github.com/')
                        .proxy(config.proxy)
                        .set('Authorization', `token ${user.GithubToken.access_token}`)
                        .set('User-Agent', 'HydroBot');
                    if (result.status !== 200) {
                        if (!user.GithubToken.refresh_token) throw new InvalidTokenError();
                        const r = await superagent.post('https://github.com/login/oauth/access_token')
                            .proxy(config.proxy)
                            .set('User-Agent', 'HydroBot')
                            .send({
                                grant_type: 'refresh_token',
                                client_id: config.client_id,
                                client_secret: config.client_secret,
                                refresh_token: user.GithubToken.refresh_token,
                            });
                        if (!r.body.access_token) throw new InvalidTokenError();
                        await app.database.setUser(session.platform, session.userId, { GithubToken: r.body });
                        return r.body.access_token;
                    }
                    return user.GithubToken.access_token;
                }
                let result;
                try {
                    result = await events[relativeEvent.type].interact(parsedMsg.trim(), session, relativeEvent, getToken);
                    console.log(result);
                } catch (e) {
                    console.log('catch', e);
                    if (e instanceof InvalidTokenError) {
                        return session.send('请先使用 github.auth <username> 或 github.token <token> 设置凭据。');
                    }
                    throw e;
                }
                const [message, $set] = result;
                if (message) await session.send(message);
                if ($set) await collData.updateOne({ _id: relativeEvent._id }, { $set });
            } catch (e) {
                const info = [e.message];
                if (typeof e.body?.message === 'string') info.push(e.body.message);
                if (typeof e.body?.error?.message === 'string') info.push(e.body.error.message);
                session.send(info.join('\n'));
            }
            return next();
        });

        app.select('groupId').command('github.repo <name>')
            .action(async (_, name) => {
                try {
                    const res = await superagent.get(`https://${name.replace('github.com', 'github.undefined.moe')}`);
                    const page = new JSDOM(res.text);
                    const t = page.window.document.querySelector('meta[property="og:image"]')
                        ?.getAttribute('content')
                        .replace('opengraph.githubassets.com', 'github.undefined.moe/opengraph')
                        .replace('avatars.githubusercontent.com', 'github.undefined.moe/avatars');
                    const a = page.window.document.querySelector('meta[property="og:image:alt"]')
                        ?.getAttribute('content').replace(/ Contribute to .+ development by creating an account on GitHub\./g, '');
                    if (t && !t.includes('opengraph')) return a + s.image(t);
                    if (t) return s.image(t);
                } catch (e) {
                    // Repo not found
                }
            });

        app.select('groupId').command('github.listen <repo>', '监听一个Repository的事件')
            .action(async ({ session }, repo) => {
                repo = repo.toLowerCase();
                if (repo.split('/').length !== 2) return '无效地址';
                const current = await coll.findOne({ _id: repo });
                if (current) {
                    await coll.updateOne(
                        { _id: repo },
                        { $addToSet: { target: `${session.platform}:${session.groupId}` } },
                        { upsert: true },
                    );
                    return `Watching ${repo}`;
                }
                await coll.insertOne({ _id: repo, target: [`${session.platform}:${session.groupId}`] });
                return `Watching ${repo}
(请创建 webhook 投递至 https://github.undefined.moe/webhook ，格式 application/json )`;
            });

        app.select('groupId').command('github.list', 'List repos')
            .action(async ({ session }) => {
                const repos = await coll.find({ target: `${session.platform}:${session.groupId}` }).project({ _id: 1 }).toArray();
                return repos.map((doc) => doc._id).join('\n');
            });

        app.select('groupId').command('github.cancel <repo>', '取消一个Repository的事件')
            .action(async ({ session }, repo) => {
                await coll.updateOne(
                    { _id: repo.toLowerCase() },
                    { $pull: { target: `${session.platform}:${session.groupId}` } },
                );
                return `Cancelled ${repo}.`;
            });

        app.command('github.token <token>', '设置token')
            .userFields(['GithubToken'])
            .action(async ({ session }, token) => {
                session.user.GithubToken = {
                    access_token: token,
                    refresh_token: '',
                };
                return '设置成功';
            });

        app.command('github.auth <username>', '登录账号')
            .userFields(['GithubToken'])
            .action(async ({ session }, login) => `请点击下面的链接继续操作：
https://github.com/login/oauth/authorize?client_id=${config.client_id}&state=${session.platform}:${session.userId}&redirect_url=${config.redirect_uri}&scope=admin%3Arepo_hook%2Crepo&login=${login}`); // eslint-disable-line
    });
};
