import superagent from 'superagent';
import { Context } from 'koishi-core';

declare module 'koishi-core' {
    interface User {
        hydroWarn: number;
    }
}

export function apply(ctx: Context) {
    ctx.select('channelId', '1091497622').on('before-attach-user', (session, fields) => fields.add('hydroWarn'));
    ctx.select('channelId', '1091497622').middleware((session, next) => next(async (next) => {
        const res = /luogu[a-z0-9A-Z.+*@#$%^&()!    ]+\/discuss\/show\/(\d+)/g.exec(session.content);
        if (res && res[1]) {
            const result = await superagent.get(`https://www.luogu.com.cn/discuss/show/${res[1]}`);
            if ((result.text || result.body).includes('target="_blank">灌水区</a></span>')) {
                if (!session.user.hydroWarn) session.send('警告：请勿发送灌水版内容。');
                session.user.hydroWarn = (session.user.hydroWarn || 0) + 1;
                session.bot.deleteMessage(session.channelId, session.messageId);
            }
        }
        return await next();
    }), true);
}
