/* eslint-disable no-template-curly-in-string */
import { totalmem, freemem } from 'os';
import { Context, template } from 'koishi-core';
import * as KoishiPluginStatus from 'koishi-plugin-webui';
import moment from 'moment';

declare module 'koishi-plugin-webui' {
    interface Status {
        totalSendCount: number,
        totalReceiveCount: number,
        usedmem: number,
        totalmem: number,
    }
}

export async function apply(ctx: Context, config: any) {
    config.title = 'Bot::Console';
    ctx.plugin(KoishiPluginStatus, config);
    template.set('status', {
        bot: '{{ username }}：{{ code ? `无法连接` : `工作中（${currentRate[0]}/min）` }}',
        output: [
            '{{ bots }}',
            '==========',
            '活跃用户数量：{{ activeUsers }}',
            '活跃群数量：{{ activeGroups }}',
            'CPU 使用率：{{ (cpu[0] * 100).toFixed() }}% / {{ (cpu[1] * 100).toFixed() }}%',
            '内存使用率：{{ (memory[0] * 100).toFixed() }}% / {{ (memory[1] * 100).toFixed() }}%',
        ].join('\n'),
    });

    ctx.app.on('connect', () => {
        const c = ctx.app.database.mongo.collection('message');

        ctx.app.webui.sources.meta.extend(async () => {
            const status: any = {};
            const udocs = await Promise.all(
                ctx.app.bots.map((bot) => ctx.app.database.getUser(bot.platform, bot.selfId.toString())),
            );
            const ids = udocs.map((i) => i?.id).filter((i) => !!i);
            const time = { time: { $gt: moment().add(-1, 'day').toDate() } };
            status.activeUsers = await ctx.app.database.mongo.user.find({}).count();
            status.totalSendCount = await c.find({ ...time, sender: { $in: ids.map(parseInt) } }).count();
            status.totalReceiveCount = await c.find({ ...time, sender: { $nin: ids.map(parseInt) } }).count();
            status.usedmem = Math.floor((totalmem() - freemem()) / 1024 / 1024);
            status.totalmem = Math.floor(totalmem() / 1024 / 1024);
            return status;
        });
    });
}
