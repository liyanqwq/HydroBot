import { exec } from 'child_process';

export default async function shellExecute(command: string) {
    let p: string;
    try {
        p = await new Promise((resolve, reject) => {
            exec(command, (err, stdout, stderr) => {
                if (err) reject(err);
                resolve(stdout + stderr);
            });
        });
    } catch (e) {
        return e.toString();
    }
    if (!p.trim().length) return '(execute success)';
    return p;
}
