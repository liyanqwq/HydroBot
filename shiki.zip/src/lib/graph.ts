import AnsiUp from 'ansi_up';
import ReactDomServer from 'react-dom/server';
import { Canvas } from 'canvas';
import type { Page } from 'puppeteer-core';

const echarts: typeof import('echarts') = eval('require')('echarts');
const AU = new AnsiUp();

export async function text2png(ctx: any, content: any) {
    const page: Page = ctx.session ? await ctx.session.app.puppeteer.page() : ctx;
    // eslint-disable-next-line max-len
    const str = typeof content === 'string' ? `<pre style="font-family:'Source Code Pro', Consolas, 'Microsoft Yahei', HYShuaiXianTiW;font-size:14px;max-width:630px">${AU.ansi_to_html(content)}</pre>`
        : ReactDomServer.renderToString(content);
    let s: Buffer;
    let e: Error;
    try {
        await page.setViewport({
            height: 30, width: 30,
        });
        await page.setContent(str);
        const element = typeof content === 'string' ? await page.$('pre') : await page.$('body');
        const size = typeof content === 'string' ? await page.evaluate(() => {
            // eslint-disable-next-line no-undef
            const ele = document.getElementsByTagName('pre')[0];
            return {
                width: ele.scrollWidth,
                height: ele.scrollHeight,
            };
        }) : await page.evaluate(() => {
            // eslint-disable-next-line no-undef
            const ele = document.body;
            return {
                width: ele.scrollWidth,
                height: ele.scrollHeight,
            };
        });;
        const clip = await element.boundingBox();
        await page.setViewport({
            width: Math.ceil(size.width + 14),
            height: Math.ceil(clip.height + 14),
        });
        s = await page.screenshot({ type: 'jpeg' });
    } catch (err) {
        e = err;
    } finally {
        if (ctx.session) await page.close();
    }
    if (e) throw e;
    return (s || Buffer.from('')).toString('base64');
}

export function echarts2dataUrl(config, width = 300, height = 300) {
    const ctx = new Canvas(1920, 1080);
    echarts.setCanvasCreator(() => ctx as any);
    config.animation = false;
    const cvs = new Canvas(width, height);
    const chart = echarts.init(cvs as any);
    chart.setOption(config);
    const res = cvs.toDataURL();
    chart.dispose();
    return res;
}
