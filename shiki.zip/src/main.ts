/* eslint-disable no-undef */
/* eslint-disable import/first */
/* eslint-disable import/no-duplicates */
/* eslint-disable import/no-dynamic-require */
/* eslint-disable global-require */
/* eslint-disable no-await-in-loop */
import path from 'path';
import {
    App, Command, Session, template,
} from 'koishi-core';
import { Logger, noop } from 'koishi-utils';
import fs from 'fs-extra';
import * as KoishiPluginMongo from 'koishi-plugin-mongo';
import 'koishi-adapter-onebot';
import 'koishi-adapter-telegram';
import 'koishi-adapter-discord';
import 'koishi-adapter-minecraft-dev';

// @ts-ignore
process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;
process.on('unhandledRejection', (_, p) => {
    console.log('Unhandled Rejection:', p);
});
Error.stackTraceLimit = 50;
Logger.showDiff = false;
Logger.showTime = 'MM-dd hh:mm:ss';
Command.defaultConfig.checkArgCount = true;
template.set('internal', {
    // command
    'low-authority': '权限不足（）',
    'usage-exhausted': '诶呀，你今天调用次数已经达到上限了哦）',
    'too-frequent': '你打字的速度太快啦！',
    'insufficient-arguments': '诶 是不是少了什么参数呢？使用“>help 指令名”可以查看用法哦',
    'redunant-arguments': '存在多余参数，使用“>help 指令名”可以查看用法哦',
    'invalid-argument': '参数 {0} 错了哦，{1}',
    'unknown-option': '存在未知选项 {0}，使用“>help 指令名”可以查看用法哦',
    'invalid-option': '选项 {0} 错了哦，{1}',
    'check-syntax': '使用“>help 指令名”可以查看用法哦',

    // parser
    'invalid-number': '请提供一个数字。',
    'invalid-integer': '请提供一个整数。',
    'invalid-posint': '请提供一个正整数。',
    'invalid-date': '请输入合法的时间。',
    'invalid-user': '请指定正确的用户。',
    'invalid-channel': '请指定正确的频道。',

    // suggest
    suggestion: '您要找的是不是{0}呢（？',
    'command-suggestion-prefix': '',
    'command-suggestion-suffix': '发送小数点或句号以使用推测的指令。',

    // help
    'help-suggestion-prefix': '指令没有找到耶（）',
    'help-suggestion-suffix': '发送小数点或句号以使用推测的指令。',
    'subcommand-prolog': '可用的子指令有{0}：',
    'global-help-prolog': '当前可用的指令有{0}：',
    'global-help-epilog': '输入“>help 指令名”查看特定指令的语法和使用示例。',
    'available-options': '可用的选项有：',
    'available-options-with-authority': '可用的选项有（括号内为额外要求的权限等级）：',
    'option-not-usage': '（不计入总次数）',
    'hint-authority': '括号内为对应的最低权限等级',
    'hint-subcommand': '标有星号的表示含有子指令',
    'command-aliases': '别名：{0}。',
    'command-examples': '使用示例：',
    'command-authority': '最低权限：{0} 级。',
    'command-max-usage': '已调用次数：{0}/{1}。',
    'command-min-interval': '距离下次调用还需：{0}/{1} 秒。',
});

declare global {
    interface String {
        decode: () => string,
        encode: () => string,
    }
}
declare module 'koishi-core' {
    interface Session {
        _silent: boolean,
        executeSilent(content: string, next?: NextFunction): Promise<string>;
        executeilent(argv: Argv, next?: NextFunction): Promise<string>;
    }
}

String.prototype.decode = function decode() {
    return this.replace(/&#91;/gm, '[').replace(/&#93;/gm, ']').replace(/&amp;/gm, '&');
};
String.prototype.encode = function encode() {
    return this.replace(/&/gm, '&amp;').replace(/\[/gm, '&#91;').replace(/\]/gm, '&#93;');
};
Session.prototype.executeSilent = function executeSilent(this: Session, arg0: any, arg1?: any) {
    this._silent = true;
    this.send = noop;
    this.sendQueued = noop;
    return this.execute(arg0, arg1);
};

class Main {
    config: Record<string, any>;

    app: App;

    logger: Logger;

    constructor(item) {
        this.logger = new Logger('main');
        this.config = item.config;
        global.proxy = item.config.proxy;
        this.app = new App({
            port: this.config.port,
            bots: this.config.bots,
            type: this.config.type,
            onebot: this.config.onebot,
            telegram: this.config.telegram,
            discord: this.config.discord,
            prefix: this.config.prompt as string,
            help: { authority: 1 },
            autoAuthorize: 1,
            autoAssign: true,
            minSimilarity: 0.7,
        });
        this.run();
    }

    async run() {
        fs.ensureDirSync(path.resolve(__dirname, '..', '.cache'));
        this.app.plugin(KoishiPluginMongo, this.config.db);
        this.app.on('connect', async () => {
            for (const line of this.config.admin) {
                const users = line.split('&');
                let found;
                for (const user of users) {
                    const [type, id] = user.split(':');
                    const udoc = await this.app.database.getUser(type, id);
                    if (udoc) found = [type, id];
                }
                const map = Object.assign({}, ...users.map((i) => i.split(':')).map((i) => ({ [i[0]]: i[1] })));
                if (found) {
                    this.app.database.setUser(found[0], found[1], { ...map, authority: 5, sudoer: true });
                }
                this.logger.info(`Opped ${line}`);
            }
            this.app.command('help').shortcut('帮助', { fuzzy: true, prefix: true });
            this.app.command('help')._aliases = [];
        });
        await this.load();
        await this.app.start();
    }

    async load() {
        for (const plugin of this.config.enabledplugins) {
            try {
                if (typeof plugin === 'string') {
                    if (plugin.startsWith('~')) {
                        let m = require(`./plugins/${plugin.split('~')[1]}`);
                        if (!m.name) {
                            if (m.apply) m.name = plugin.split('~')[1];
                            else m = { name: plugin.split('~')[1], apply: m };
                        }
                        this.app.plugin(m);
                        // eslint-disable-next-line no-eval
                    } else this.app.plugin(eval('require')(plugin).apply);
                } else if (plugin instanceof Array) {
                    if (plugin[0].startsWith('~')) {
                        let m = require(`./plugins/${plugin[0].split('~')[1]}`);
                        if (!m.name) {
                            if (m.apply) m.name = plugin[0].split('~')[1];
                            else m = { name: plugin[0].split('~')[1], apply: m };
                        }
                        this.app.plugin(m, plugin[1]);
                        // eslint-disable-next-line no-eval
                    } else this.app.plugin(eval('require')(plugin[0]), plugin[1]);
                }
            } catch (e) {
                this.logger.error('Failed to load ', plugin, e);
            }
        }
    }
}

export = Main;
// @ts-ignore
global.Main = Main;
